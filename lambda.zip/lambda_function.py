from neo4j import GraphDatabase
import os

# Configuración de la conexión a Neo4j
neo4j_uri = os.environ.get('NEO4J_URI')
neo4j_user = os.environ.get('NEO4J_USER')
neo4j_password = os.environ.get('NEO4J_PASSWORD')

# Inicializar el cliente de Neo4j
neo4j_driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))

# Función para manejar el evento de Post Confirmation en AWS Cognito
def lambda_handler(event, context):
    try:
        # Verificar si el evento es de Post Confirmation
        if event['triggerSource'] == 'PostConfirmation_ConfirmSignUp':
            # Obtener los datos del usuario recién confirmado
            user_attributes = event['request']['userAttributes']
            user_id = user_attributes['sub']
            user_email = user_attributes['email']
            # Puedes agregar más campos según tus necesidades

            # Crear un nodo de usuario en Neo4j
            with neo4j_driver.session() as session:
                session.run(
                    "CREATE (u:User {userId: $userId, email: $email})",
                    userId=user_id,
                    email=user_email
                    # Puedes agregar más propiedades según tus necesidades
                )
            print("Nodo de usuario creado en Neo4j")
    except Exception as e:
        print(f"Error al manejar el evento de Post Confirmation: {e}")
        raise e

# Llama a la función lambda_handler cuando se ejecuta el script localmente
if __name__ == "__main__":
    # Simula un evento de Post Confirmation
    event = {
        "triggerSource": "PostConfirmation_ConfirmSignUp",
        "request": {
            "userAttributes": {
                "sub": "user2",
                "email": "user2@example.com"
                # Puedes agregar más atributos según tus necesidades
            }
        }
    }
    lambda_handler(event, None)
